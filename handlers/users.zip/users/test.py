


f_qator="0"
nomer = "0"
msg = "5542049549"



f = open("hammasi", "r")
while 1 == 1:
    f_qator = f.readline()
    if msg in f_qator:
        sum = len(f_qator)
        for j in range(sum-14):
            if f_qator[j] == " " and f_qator[j+13]:
                nomer = f_qator[j+1:j+13]
            if f_qator[j] == " " and f_qator[j+14]:
                nomer = f_qator[j+1:j+14]
        break
    print(f_qator)
    if f_qator == "":
        break
f.close()
print(nomer)
